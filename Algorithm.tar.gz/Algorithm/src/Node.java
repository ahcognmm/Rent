import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

public class Node {

    int vertices;
    private HashMap<Integer, LinkedList<Integer>> adj = new HashMap<>();
    int[] values;

    public Node(int vertices, int... value) {

        this.vertices = vertices;
        this.values = value;
        for (int v : values) {
            adj.put(v, new LinkedList<>());
        }
    }

    public void addEdge(int dataPar, int dataChil) {
        adj.get(dataPar).add(dataChil);
//        adj.get(dataChil).add(dataPar);
    }

    public void printNode() {
        for (int v : values) {
            System.out.println(adj.get(v).toString());
        }
    }

    public void bfs(int startNode, int endNode) {

        LinkedList<Integer> result = new LinkedList<>();
        HashMap<Integer, Boolean> visted = new HashMap<>();
        HashMap<Integer, Boolean> inQueue = new HashMap<>();
        LinkedList<Integer> queue = new LinkedList<>();


        for (int i : values) {
            visted.put(i, false);
            inQueue.put(i, false);
        }
        queue.add(startNode);
        inQueue.put(startNode, true);

        while (queue.size() != 0) {

            for (int i : adj.get(queue.getFirst())) {
                if (!visted.get(i) && !inQueue.get(i)) {
                    queue.add(i);
                    inQueue.put(i, true);
                }
            }
            visted.put(queue.getFirst(), true);
            result.add(queue.getFirst());
            if (queue.getFirst() == endNode) {
                break;
            }
            queue.pop();
        }

        System.out.println(result.toString());

    }

    public void dfs(int startNode) {

        LinkedList<Integer> result = new LinkedList<>();
        LinkedList<Integer> queue = new LinkedList<>();
        HashMap<Integer, Boolean> visited = new HashMap<>();


        boolean hasNode = true;
        HashMap<Integer, Boolean> inQueue = new HashMap<>();

        for (int i : values) {
            visited.put(i, false);
            inQueue.put(i, false);
        }

        queue.add(startNode);
        result.add(startNode);
        inQueue.put(startNode, true);
        visited.put(startNode, true);

        while (queue.size() != 0) {
            int test = queue.getLast();
            for (int i : adj.get(queue.getLast())) {
                if (!visited.get(i)) {
                    queue.add(i);
                    visited.put(i, true);
                    inQueue.put(i, true);
                    result.add(i);
                    hasNode = true;
                    break;
                }
            }

            if (adj.get(queue.getLast()).size() != 0) {
                for (int i : adj.get(queue.getLast())) {
                    if (visited.get(i) && inQueue.get(i)) {
                        hasNode = false;
                    } else {
                        hasNode = true;
                        break;
                    }
                }
            } else hasNode = false;
            if (!hasNode) {
                queue.pollLast();
            }
        }
        System.out.println(result.toString());
    }

    public ArrayList<Integer> result(int level) {
        ArrayList result = new ArrayList();
        LinkedList<Integer> queue = new LinkedList<>();
        HashMap<Integer, Boolean> visited = new HashMap<>();
        boolean hasNode = false;


        for (int i : values) {
            visited.put(i, false);
        }
        queue.add(1);
        visited.put(1, true);

        while (queue.size() != 0) {
            for (int i : adj.get(queue.getLast())) {
                if (!visited.get(i)) {
                    queue.add(i);
                    visited.put(i, true);
                    hasNode = true;
                    break;
                }
            }
            if (adj.get(queue.getLast()).size() != 0) {
                for (int i : adj.get(queue.getLast())) {
                    if (visited.get(i)) {
                        hasNode = false;
                    } else {
                        hasNode = true;
                        break;
                    }
                }
            } else hasNode = false;
            if (queue.size() == level) {
                result.add(queue.get(level-1));
            }
            if (!hasNode || queue.size() == level) {
                queue.pollLast();
            }
        }

        return result;
    }
}
