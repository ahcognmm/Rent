package com.chatchat.chatchat.Model;

/**
 * Created by Thong Pham on 23/08/2017.
 */

public class Forum {

    public String name;

    public String code;

    public int order;

    public Forum(String name, String code, int order){
        this.name = name;
        this.code = code;
        this.order = order;
    }

}
